import React, { useState, useEffect } from "react";
import ImageGallery from "./components/ImageGallery";
import SearchBar from "./components/SearchBar";
import { getImages } from "./services/unsplashApi";
import "react-toastify/dist/ReactToastify.css"; // Import the Toastify CSS
import Spinner from './components/Spinner '

function App() {
  const [images, setImages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [error, setError] = useState("");

  useEffect(() => {
    const fetchImages = async (query, page) => {
      setLoading(true);
      try {
        const data = await getImages(query, page);
        setImages(data);
      } catch (error) {
        console.error("Error fetching images: ", error);
        setError("Rate Limit Exceeded. Please try again later.");
      } finally {
        setLoading(false);
      }
    };

    fetchImages(searchTerm, currentPage);
  }, [searchTerm, currentPage]);

  const handlePageChange = (pageNumber) => {
    if (!loading) {
      setCurrentPage(pageNumber);
    }
  };

  const handleSearchSubmit = (searchTerm) => {
    setSearchTerm(searchTerm);
    setCurrentPage(1); // Reset to the first page when searching
  };

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-3xl font-bold text-center mb-10">Photo Gallery</h1>
      <SearchBar searchTerm={searchTerm} onSearch={handleSearchSubmit} />
      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 my-3 py-3 rounded relative" role="alert">
          <span>{error}</span>
        </div>
      )}
      {!error && (
        <>
          {loading ? (
          <Spinner /> // Display the spinner component when loading
        ) : (
            <>
              <ImageGallery images={images} />
              <div className="flex items-center justify-center mt-4">
                <button
                  onClick={() => handlePageChange(currentPage - 1)}
                  disabled={currentPage === 1 || loading}
                  className={`bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-l focus:outline-none ${currentPage === 1 ? 'cursor-not-allowed' : 'cursor-pointer'}`}
                >
                  Prev
                </button>
                <span className="mx-4 text-lg font-semibold">{currentPage}</span>
                <button
                  onClick={() => handlePageChange(currentPage + 1)}
                  disabled={loading}
                  className={`bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-r focus:outline-none`}
                >
                  Next
                </button>
              </div>
            </>
          )}
        </>
      )}
    </div>
  );
}

export default App;