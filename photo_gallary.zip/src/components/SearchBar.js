import React from "react";

const SearchBar = ({ searchTerm, onSearch }) => {
  const handleSearch = (e) => {
    onSearch(e.target.value);
  };

  return (
    <input
      type="text"
      placeholder="Search images..."
      value={searchTerm}
      onChange={handleSearch}
      className="w-full p-2 border"
    />
  );
};

export default SearchBar;