import React, { useState } from "react";
import ImageModal from "./ImageModal";

const ImageCard = ({ image }) => {
  const [showModal, setShowModal] = useState(false);

  const openModal = () => {
    setShowModal(true);
  };

  return (
    <div className="w-auto cursor-pointer group relative">
      <img
        src={image.url}
        alt={image.alt}
        onClick={openModal}
        className="w-full h-64 object-cover transform duration-300 group-hover:scale-105"
      />
      {showModal && <ImageModal image={image} closeModal={() => setShowModal(false)} />}
    </div>
  );
};

export default ImageCard;