import React from "react";
import ImageCard from "../components/ImageCard";

const ImageGallery = ({ images }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-5 my-6">
      {images.map((image) => (
        <ImageCard key={image.id} image={image} />
      ))}
    </div>
  );
};

export default ImageGallery;