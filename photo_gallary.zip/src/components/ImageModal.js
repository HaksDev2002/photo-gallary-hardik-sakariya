const ImageModal = ({ image, closeModal }) => {
  console.log(image,"Image")
  return (
    <div className="fixed top-0 left-0 flex justify-center items-center w-full h-full bg-black bg-opacity-50 z-50 overflow-y-auto">
      <div className="p-4 bg-white max-w-md mx-4 md:mx-auto rounded-lg shadow-lg">
        <div className="relative">
          <button className="absolute top-2 right-2 text-white border border-white" onClick={closeModal}>
            <svg className="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
            </svg>
          </button>
          <img
            src={image.url}
            alt={image.alt}
            className="w-full h-auto object-cover rounded-t-lg"
            style={{ aspectRatio: '16/9' }}
          />
        </div>
        <div className="">
          <p className="text-gray-800 font-bold text-lg mt-2">Photographer: {image.photographer}</p>
          {image.description ? <p className="text-gray-800 font-semibold mt-2"> Desc: {image.description}</p> : <p></p>}
          <p className="text-gray-700 mt-2">Alt: {image.alt}</p>
        </div>
      </div>
    </div>
  );
};

export default ImageModal;